package com.example.projecttwo_austinfreeman;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.navigation.NavigationView;

import java.time.LocalDate;
import java.time.Year;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.util.ArrayList;
import java.time.DayOfWeek;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;


public class DiaryActivity extends AppCompatActivity {
    private UserDatabase dbHelper;
    private WeightDatabase weightDB;
    private YearMonth currentMonth;
    private String user;
    private boolean useKg;
    private Map<String, String> weightEntries = new HashMap<>();
    private Map<String, String> goals;

    private GridView calendarGrid;


    DayOfWeek[] weekDays = {
            DayOfWeek.SUNDAY,
            DayOfWeek.MONDAY,
            DayOfWeek.TUESDAY,
            DayOfWeek.WEDNESDAY,
            DayOfWeek.THURSDAY,
            DayOfWeek.FRIDAY,
            DayOfWeek.SATURDAY
    };

    //Broke this off the onCreate to have this built separately
    public void buildGrid(LocalDate t) {

        GridView gridView = findViewById(R.id.grid_view);
        TextView item = findViewById(R.id.format_date);

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMMM yyyy");

        String formattedDate = t.format(formatter);
        LocalDate firstDayOfMonth = t.withDayOfMonth(1);
        String previousWeight = weightDB.getWeightForDate(user, firstDayOfMonth.minusDays(1).toString());
        DayOfWeek testDate = firstDayOfMonth.getDayOfWeek();
        item.setText(formattedDate);

        ArrayList<Model> list = new ArrayList<>();
        for(DayOfWeek day : weekDays) {
            String dayName = day.getDisplayName(
                    TextStyle.SHORT,
                    Locale.getDefault()
            );
            list.add(new Model(dayName, false));
        }

        String goalDate = null;
        if(goals != null && !goals.isEmpty()) {
            goalDate = goals.get("projectedDate");
        }

        int dateTrack = 1;
        boolean found = false;

        for(int i = 0; i < 35 || dateTrack <= t.lengthOfMonth(); i++) {
            String res = "";
            if (weekDays[i % 7] == testDate && !found) {
                found = true;
            }
            if (found && dateTrack <= t.lengthOfMonth()) {
                int day = dateTrack;
                LocalDate cellDate = t.withDayOfMonth(day);
                String savedWeight = weightEntries.get(cellDate.toString());

                res = Integer.toString(day);

                if(savedWeight != null) {
                    double current = Double.parseDouble(savedWeight);

                    int trend = 0;

                    if(previousWeight != null) {
                        double previous = Double.parseDouble(previousWeight);

                        if(current < previous) {
                            trend = -1;
                        } else if(current > previous) {
                            trend = 1;
                        }
                    }

                    list.add(new Model(res, true, Double.parseDouble(savedWeight), trend));
                } else if(goalDate != null && cellDate.toString().equals(goalDate)) {
                    list.add(new Model(res, true, 2));
                }else {
                    list.add(new Model(res, true));
                }
                previousWeight = savedWeight;
                dateTrack++;
            }
            else {
                found = false;
                list.add(new Model("", false));
            }
        }

        GridViewCreator adapt = new GridViewCreator(this, list, useKg);

        gridView.setAdapter(adapt);
    }
    private void loadMonth() {
        String month = currentMonth.toString();
        weightEntries = weightDB.getUserEntries(user, month);

        goals = weightDB.getGoals(user);

        if(!goals.isEmpty()) {
            String toggle = goals.get("toggle");

            useKg  = "1".equals(toggle);
        }
    }

    private void refreshCalendar() {
        loadMonth();
        buildGrid(currentMonth.atDay(1));
    }

    //When created set the content view and build the grid
    @Override
    public void onCreate(Bundle instance) {
        super.onCreate(instance);
        setContentView(R.layout.main_screen);

        dbHelper = new UserDatabase(this);
        weightDB = new WeightDatabase(this);
        user = dbHelper.getUser(Long.toString(dbHelper.getLogged()));
        calendarGrid = findViewById(R.id.grid_view);
        currentMonth = YearMonth.now();
        refreshCalendar();

        ImageButton prevMonth = findViewById(R.id.imageButton);
        ImageButton nextMonth = findViewById(R.id.imageButton2);

        prevMonth.setOnClickListener(v -> {
            currentMonth = currentMonth.minusMonths(1);
            refreshCalendar();
        });

        nextMonth.setOnClickListener(v -> {
            currentMonth = currentMonth.plusMonths(1);
            refreshCalendar();
        });



        DrawerLayout drawerLayout =findViewById(R.id.drawer_layout);
        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        NavigationView navigationView = findViewById(R.id.navigation_view);

        ViewCompat.setOnApplyWindowInsetsListener(toolbar,(view, insets) -> {
            Insets systemBars = insets.getInsets(
                    WindowInsetsCompat.Type.statusBars()
            );

            view.setPadding(
                    view.getPaddingLeft(),
                    systemBars.top,
                    view.getPaddingRight(),
                    view.getPaddingBottom()
            );
            return insets;
        });
        toolbar.setOnMenuItemClickListener(item -> {
            if(item.getItemId() == R.id.action_account) {
                Intent i = new Intent(
                        DiaryActivity.this, AccountActivity.class
                );
                startActivity(i);
                return true;
            }
            return false;
        });


        toolbar.setNavigationOnClickListener(v -> {
            drawerLayout.open();
        });

        navigationView.setNavigationItemSelectedListener(item -> {
            int id = item.getItemId();

            if(id == R.id.menu_diary) {

            }
            else if(id == R.id.menu_goals) {
                Intent i = new Intent(
                        DiaryActivity.this,
                        GoalsActivity.class
                );
                startActivity(i);
            } else if(id == R.id.menu_settings) {
                Intent i = new Intent(
                        DiaryActivity.this,
                    SMS_NotificationActivity.class
                );
                startActivity(i);

            } else if(id == R.id.menu_logout) {
                dbHelper.logOut();
                Intent i = new Intent(
                        DiaryActivity.this,
                        MainActivity.class
                );
                startActivity(i);
                finish();
            }
            drawerLayout.close();
            return true;
        });


        FloatingActionButton entry = findViewById(R.id.floatingActionButton);

        entry.setOnClickListener(v -> {
            Intent i = new Intent(
                    DiaryActivity.this, CreateEntry.class
            );

            startActivity(i);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        if(weightDB != null && user != null) {
            currentMonth = YearMonth.now();
            refreshCalendar();
        }
    }
}

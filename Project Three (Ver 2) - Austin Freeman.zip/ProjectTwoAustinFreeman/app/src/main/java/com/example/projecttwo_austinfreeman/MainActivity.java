package com.example.projecttwo_austinfreeman;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import android.database.sqlite.SQLiteDatabase;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle instance) {
        super.onCreate(instance);
        setContentView(R.layout.login_screen);

        Button intentSwitch = findViewById(R.id.button);
        TextView register = findViewById(R.id.register_text);

        EditText username = findViewById(R.id.username);
        EditText password = findViewById(R.id.password2);

        UserDatabase dbHelper = new UserDatabase(this);


        //Create a listener that checks to see if the button has been click
        //Todo: Once we move forward in the project we can change this to a onClick that adds another editText and changes the login to a registration page
        register.setOnClickListener(v -> {
            Toast.makeText(MainActivity.this, "Redirecting to registration...", Toast.LENGTH_SHORT).show();
            Intent i = new Intent(
                    MainActivity.this, RegisterActivity.class
            );
            startActivity(i);
        });

        intentSwitch.setOnClickListener(v -> {
            String user = username.getText().toString();
            String pass = password.getText().toString();

            boolean valid = dbHelper.getUser(user, pass);

            if(valid) {
                dbHelper.logIn(user);
                Intent i = new Intent(
                        MainActivity.this, DiaryActivity.class
                );
                startActivity(i);
                finish();
            } else {
                Toast.makeText(MainActivity.this, "Invalid login...", Toast.LENGTH_SHORT).show();
            }
        });

    }

}

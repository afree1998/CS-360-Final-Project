package com.example.projecttwo_austinfreeman;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.appbar.MaterialToolbar;

import org.w3c.dom.Text;

import java.time.LocalDate;

public class GoalsActivity extends AppCompatActivity {
    boolean toggle = false;
    UserDatabase dbHelper = new UserDatabase(this);

    double stepVal;
    @Override
    protected void onCreate(Bundle instance) {
        super.onCreate(instance);
        setContentView(R.layout.goal_screen);

        int stepSize = 25;
        SeekBar seekbar = findViewById(R.id.seekBar);
        TextView t = findViewById(R.id.weight_lost);
        TextView toggleItem = findViewById(R.id.next_toggle);
        TextView toggleTwo = findViewById(R.id.weight_toggle);
        Button save = findViewById(R.id.saveWeight);
        Switch convert = findViewById(R.id.switch1);
        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        //Properties
        EditText age = findViewById(R.id.Age);
        EditText weight = findViewById(R.id.currentWeight);
        EditText goal = findViewById(R.id.goalWeight);

        //User
        String user = dbHelper.getUser(Long.toString(dbHelper.getLogged()));



        ViewCompat.setOnApplyWindowInsetsListener(toolbar,(view, insets) -> {
            Insets systemBars = insets.getInsets(
                    WindowInsetsCompat.Type.statusBars()
            );

            view.setPadding(
                    view.getPaddingLeft(),
                    systemBars.top,
                    view.getPaddingRight(),
                    view.getPaddingBottom()
            );
            return insets;
        });
        toolbar.setNavigationOnClickListener(v -> {
            onBackPressed();
        });

        convert.setOnClickListener(v -> {
            toggle = !toggle;

            if(toggle) {
                toggleItem.setText("kgs");
                toggleTwo.setText("kgs");
                t.setText(String.format("%.2f", stepVal / 2.205) + "kgs");
            } else {
                toggleItem.setText("lbs");
                toggleTwo.setText("lbs");
                t.setText(stepVal + "lbs");
            }
        });

        seekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int stepProgress = Math.round((float) progress / stepSize) * stepSize;
                if(progress != stepProgress) {
                    if(!toggle) {
                        stepVal = (stepProgress * 2 * .01);
                        t.setText(stepVal + "lbs");
                        seekBar.setProgress(stepProgress);
                    } else {
                        stepVal = (stepProgress * 2 * .01 / 2.205);
                        t.setText(String.format("%.2f", stepVal) + "kgs");
                        seekBar.setProgress(stepProgress);

                    }
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        save.setOnClickListener(v -> {
            WeightDatabase db = new WeightDatabase(this);
            if(weight.getText().toString().isEmpty() || goal.getText().toString().isEmpty()) {
                Toast.makeText(GoalsActivity.this, "Please enter a current and goal weight", Toast.LENGTH_SHORT).show();
                return;
            }
            double delta = Double.parseDouble(weight.getText().toString()) - Double.parseDouble(goal.getText().toString());

            if(stepVal <= 0) {
                Toast.makeText(GoalsActivity.this, "Please select a weekly weight-loss goal", Toast.LENGTH_SHORT).show();
                return;
            }
            double projTime = delta / stepVal;
            long weeks = (long)Math.ceil(projTime);

            LocalDate projectedDate = LocalDate.now().plusWeeks(weeks);
            long goalResult = db.saveGoals(user, goal.getText().toString(), String.valueOf(stepVal), projectedDate.toString(), toggle);

            long weightResult = db.createEntry(user, LocalDate.now().toString(), weight.getText().toString(), toggle);

            if(goalResult != 1 && weightResult != 1) {
                Toast.makeText(GoalsActivity.this, "Entry succeeded...", Toast.LENGTH_SHORT).show();
                getSharedPreferences("sms_settings", MODE_PRIVATE).edit().putBoolean(user + "_goal_alert_sent", false).apply();
                Intent i = new Intent(
                        GoalsActivity.this, DiaryActivity.class
                );
                startActivity(i);
                finish();
            }
        });
    }
}

package com.example.projecttwo_austinfreeman;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.Map;

public class UserDatabase extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "users.db";
    private static final int VERSION = 3;
    public UserDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }


    private static final class UserTable {
        private static final String TABLE = "users";
        private static final String COL_ID = "_id";
        private static final String COL_USER = "username";
        private static final String COL_PASS = "password";
        private static final String COL_LOGGED = "logged";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + UserTable.TABLE + " (" +
        UserTable.COL_ID + " integer primary key autoincrement, " +
        UserTable.COL_USER + " text, " +
        UserTable.COL_PASS + " text," +
        UserTable.COL_LOGGED + " text )");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + UserTable.TABLE);
        onCreate(db);
    }

    public boolean getUser(String u, String p) {
        SQLiteDatabase db = getReadableDatabase();

        String sql = "select " + UserTable.COL_ID + " from " + UserTable.TABLE + " where " + UserTable.COL_USER + "= ?" + " and " + UserTable.COL_PASS + " = ?";
        Cursor c = db.rawQuery(sql, new String[]{u, p});

        boolean exists = c.moveToFirst();

        c.close();

        return exists;
    }

    public long userExists(String u) {
        SQLiteDatabase db = getReadableDatabase();

        String sql = "select " + UserTable.COL_ID + " from " + UserTable.TABLE + " where " + UserTable.COL_USER + "= ?";
        Cursor c = db.rawQuery(sql, new String[]{u});

        long userId = -1;

        if(c.moveToFirst()) {
            userId = c.getLong(0);
        }
        c.close();
        return userId;
    }

    public long createUser(String user, String pass) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(UserTable.COL_USER, user);
        values.put(UserTable.COL_PASS, pass);
        values.put(UserTable.COL_LOGGED, "0");

        return db.insert(UserTable.TABLE, null, values);

    }

    public long getLogged() {
        SQLiteDatabase db = getReadableDatabase();

        String sql = "select * from " + UserTable.TABLE + " where " + UserTable.COL_LOGGED + "= 1";
        Cursor c = db.rawQuery(sql, null);

        long id = -1;

        if(c.moveToFirst()) {
            id = c.getLong(c.getColumnIndexOrThrow(UserTable.COL_ID));
        }
        c.close();

        return id;
    }
    public void logIn(String user) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues l = new ContentValues();
        l.put(UserTable.COL_LOGGED, "0");

        db.update(UserTable.TABLE,
                l,
                null,
                null);


        ContentValues v = new ContentValues();
        v.put(UserTable.COL_LOGGED, "1");

        db.update(
                UserTable.TABLE,
                v,
                UserTable.COL_USER + "= ?",
                new String[]{user}
        );
        Log.d("Test", "Logged in");
    }

    public void logIn(long userId) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues v = new ContentValues();
        v.put(UserTable.COL_LOGGED, "0");

        db.update(UserTable.TABLE,
                v,
                null,
                null);

        ContentValues login = new ContentValues();
        login.put(UserTable.COL_LOGGED, "1");

        db.update(UserTable.TABLE, login, UserTable.COL_ID + " = ?", new String[]{String.valueOf(userId)});
    }

    public void logOut() {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues v = new ContentValues();
        v.put(UserTable.COL_LOGGED, "0");

        db.update(
                UserTable.TABLE,
                v,
                null,
                null
        );
    }

    public String getUser(String uID) {
        SQLiteDatabase db = getReadableDatabase();

        String sql = "Select * from " + UserTable.TABLE + " where " + UserTable.COL_ID + "= ?";
        Cursor c = db.rawQuery(sql, new String[]{uID});

        String username = null;

        if(c.moveToFirst()) {
            username = c.getString(c.getColumnIndexOrThrow(UserTable.COL_USER));
        }

        c.close();

        return username;
    }


}

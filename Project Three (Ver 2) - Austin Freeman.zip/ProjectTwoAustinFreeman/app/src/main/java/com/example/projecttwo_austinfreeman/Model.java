package com.example.projecttwo_austinfreeman;

public class Model {
    private String date;
    private boolean clickable;
    private double weight;
    private int trend;

    //Default for populating an empty field
    public Model(String date, boolean click) {
        this.date = date;
        this.weight = -1;
        this.trend = 0;
        this.clickable = click;
    }


    //This overloaded constructor is for adding entries
    public Model(String date, boolean clickable, double weight, int trend) {
        this.date = date;
        this.clickable = clickable;
        this.weight = weight;
        this.trend = trend;
    }

    public Model(String date, boolean clickable, int trend) {
        this.date = date;
        this.weight = -1;
        this.trend = trend;
        this.clickable = clickable;
    }
    public String getDate() {
        return date;
    }
    public boolean getClickable() { return clickable; }

    public double getWeight() { return weight; }

    public int getTrend() {
        return trend;
    }

    public void setWeight(double weight) { this.weight = weight; }
}

package com.example.projecttwo_austinfreeman;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import android.util.Log;

import androidx.core.content.ContextCompat;

import java.util.Map;


public class SMS_Goal {
    public static void checkGoal(Context context, String user) {
        if(ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        SharedPreferences prefs = context.getSharedPreferences("sms_settings", Context.MODE_PRIVATE);

        boolean enabled = prefs.getBoolean(user + "_sms_enabled", false);

        if(!enabled) {
            return;
        }

        String phone = prefs.getString(user +"_phone", "");

        if(phone.isEmpty()) {
            return;
        }

        if(!context.getPackageManager().hasSystemFeature(PackageManager.FEATURE_TELEPHONY_MESSAGING)) {
            return;
        }

        WeightDatabase db = new WeightDatabase(context);
        String currentWeight = db.getLatestWeight(user);
        Map<String, String> goals = db.getGoals(user);
        String goalWeight = goals.get("goalWeight");

        if(currentWeight == null || goalWeight == null) {
            return;
        }

        double current = Double.parseDouble(currentWeight);
        double goal = Double.parseDouble(goalWeight);

        boolean alreadySent = prefs.getBoolean(user + "_goal_alert_sent", false);

        if(current <= goal && !alreadySent) {
            try {
                SmsManager sms = context.getSystemService(SmsManager.class);

                if(sms != null) {
                    String message = "Congrats! \n You reached your goal!";
                    sms.sendTextMessage(phone, null, message, null, null);

                    prefs.edit().putBoolean(user + "_goal_alert_sent", true).apply();

                    Log.d("SMS", "Goal SMS Sent");
                }
            } catch(SecurityException | UnsupportedOperationException e) {
                Log.e("SMS", "Unable to send", e);
            }
        }
    }
}

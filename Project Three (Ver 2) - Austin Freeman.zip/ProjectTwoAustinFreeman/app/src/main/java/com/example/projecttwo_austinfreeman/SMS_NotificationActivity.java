package com.example.projecttwo_austinfreeman;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContract;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.textfield.TextInputEditText;

public class SMS_NotificationActivity extends AppCompatActivity {
    private TextInputEditText phoneNumber;
    private TextInputEditText verifyPhone;
    private TextView status;
    private TextView notification;

    private SharedPreferences prefs;
    private String user;
    private ActivityResultLauncher<String> smsPermissions;

    @Override
    public void onCreate(Bundle instance) {
        super.onCreate(instance);
        setContentView(R.layout.sms_alerts);


        phoneNumber = findViewById(R.id.phone_number);
        verifyPhone = findViewById(R.id.phone_number2);
        status = findViewById(R.id.permission_status);
        notification = findViewById(R.id.notificationRes);

        UserDatabase userDB = new UserDatabase(this);

        user = userDB.getUser(Long.toString(userDB.getLogged()));

        prefs = getSharedPreferences("sms_settings", MODE_PRIVATE);

        phoneNumber.setText(prefs.getString(user + "_phone", ""));

        smsPermissions = registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
            if(isGranted) {
                enableSmsForUser();
            } else {
                prefs.edit().putBoolean(user + "_sms_enabled", false).apply();

                status.setText("SMS permission denied...");

                notification.setText("SMS alerts are disabled");
            }
        });
        Button enableSms = findViewById(R.id.enableSMS);
        Button declineSms = findViewById(R.id.disableSMS);
        MaterialToolbar toolbar = findViewById(R.id.toolbar);




        ViewCompat.setOnApplyWindowInsetsListener(toolbar,(view, insets) -> {
            Insets systemBars = insets.getInsets(
                    WindowInsetsCompat.Type.statusBars()
            );

            view.setPadding(
                    view.getPaddingLeft(),
                    systemBars.top,
                    view.getPaddingRight(),
                    view.getPaddingBottom()
            );
            return insets;
        });
        toolbar.setNavigationOnClickListener(v -> {
            onBackPressed();
        });

        enableSms.setOnClickListener(v -> {
            String phone = phoneNumber.getText().toString().trim();
            String verify = verifyPhone.getText().toString().trim();

            if(phone.isEmpty()) {
                notification.setText("Enter a phone number");
                return;
            }
            if(!phone.equals(verify)) {
                notification.setText("Phone numbers don't match, try again");
                return;
            }

            if(ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                enableSmsForUser();
            } else {
                smsPermissions.launch(Manifest.permission.SEND_SMS);
            }

        });

        declineSms.setOnClickListener(v ->{
            prefs.edit().putBoolean(user + "_sms_enabled", false).apply();

            status.setText("SMS alerts disabled");
            notification.setText("Alerts have been disabled, enable to use this functionality");
        });

        updateStatus();
    }

    private void enableSmsForUser() {
        String phone = phoneNumber.getText().toString().trim();

        prefs.edit().putString(user + "_phone", phone).putBoolean(user + "_sms_enabled", true).apply();

        status.setText("SMS Permissions Granted");
        notification.setText("Goal weight alerts are enabled");
    }

    private void updateStatus() {
        boolean permissionGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;

        boolean enabled = prefs.getBoolean(user + "_sms_enabled", false);

        if(permissionGranted && enabled) {
            status.setText("SMS permission granted");
            notification.setText("Weight goal alerts are enabled");
        } else {
            status.setText("SMS alerts are not enabled");
        }


    }
}

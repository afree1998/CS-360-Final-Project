package com.example.projecttwo_austinfreeman;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.ToggleButton;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.appcompat.widget.Toolbar;

import com.google.android.material.materialswitch.MaterialSwitch;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.Map;

public class CreateEntry extends AppCompatActivity {

    WeightDatabase dbHelper;
    UserDatabase db;
    @Override
    protected void onCreate(Bundle instance) {
        super.onCreate(instance);
        setContentView(R.layout.create_entry);

        dbHelper = new WeightDatabase(this);
        db = new UserDatabase(this);

        EditText date = findViewById(R.id.editTextDate2);
        EditText weight = findViewById(R.id.editTextweight);

        Switch convert = findViewById(R.id.weight_toggle);

        String username = db.getUser(Long.toString(db.getLogged()));
        Map<String, String> goals = dbHelper.getGoals(username);

        boolean defaultKg = "1".equals(goals.get("toggle"));
        convert.setChecked(defaultKg);

        if(defaultKg) {
            convert.setText("kg");
            weight.setHint("Weight in kg");
        } else {
            convert.setText("lbs");
            weight.setHint("Weight in lbs");
        }

        Button submit = findViewById(R.id.submit);

        date.setOnClickListener(v -> {
            showDatePicker(date);
        });

        //Go back
        Toolbar toolbar = findViewById(R.id.toolbar);

        toolbar.setNavigationOnClickListener(v -> {
            finish();
        });

        convert.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if(isChecked) {
                convert.setText("kg");
                weight.setHint("Weight in kg");
            } else {
                convert.setText("lbs");
                weight.setHint("Weight in lbs");
            }
        });
        submit.setOnClickListener(v-> {
            String user = db.getUser(Long.toString(db.getLogged()));
            String date_res = date.getText().toString();
            String weight_res = weight.getText().toString();

            boolean useKg = convert.isChecked();

            if(date_res.isEmpty() || weight_res.isEmpty()) {
                return;
            }
            boolean success = false;
            int entryNum = dbHelper.getEntryMaxNum(date_res, user);
            if(entryNum > 0) {
                int res = dbHelper.updateWeight(user, date_res, entryNum, weight_res, useKg);
                success = res > 0;
            } else {
                long result = dbHelper.createEntry(user, date_res, weight_res, useKg);
                success = result != -1;
            }
            if(success) {
                SMS_Goal.checkGoal(CreateEntry.this, user);
            }
            finish();
        });

    }

    private void showDatePicker(EditText editText) {
        Calendar cal = Calendar.getInstance();
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH);
        int day = cal.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePicker = new DatePickerDialog(this,
                (view, selectedYear, selectedMonth, selectedDay) -> {
                    Calendar selectedDate = Calendar.getInstance();
                    selectedDate.set(selectedYear, selectedMonth, selectedDay);

                    SimpleDateFormat date = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
                    editText.setText(date.format(selectedDate.getTime()));
                }, year, month, day);
        datePicker.show();
    }
}

package com.example.projecttwo_austinfreeman;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import java.util.Locale;
import java.util.Map;

public class AccountActivity extends AppCompatActivity {
    private UserDatabase userDB;
    private WeightDatabase weightDB;
    private Map<String, String> goals;


    @Override
    protected void onCreate(Bundle instance) {
        super.onCreate(instance);
        setContentView(R.layout.account_view);

        userDB = new UserDatabase(this);
        weightDB = new WeightDatabase(this);

        String user = userDB.getUser(Long.toString(userDB.getLogged()));
        goals = weightDB.getGoals(user);

        String toggle = goals.get("toggle");
        boolean useKg = "1".equals(toggle);
        String currentWeight = weightDB.getLatestWeight(user);

        Toolbar toolbar = findViewById(R.id.toolbar);


        toolbar.setNavigationOnClickListener(v -> {
            finish();
        });

        TextView usernameText = findViewById(R.id.account_username);
        TextView currentWeightText = findViewById(R.id.account_current_weight);
        TextView goalWeightText = findViewById(R.id.account_goal_weight);
        TextView weeklyGoalText = findViewById(R.id.account_weekly_goal);
        TextView goalDateText = findViewById(R.id.account_goal_date);
        TextView prefUnits = findViewById(R.id.account_notifications);

        Switch unitToggle = findViewById(R.id.unit_toggle);
        unitToggle.setChecked(useKg);

        updateDisplayedWeights(currentWeightText, goalWeightText, weeklyGoalText, currentWeight, goals, useKg);

        unitToggle.setOnCheckedChangeListener(((buttonView, isChecked) -> {
            weightDB.setPrefUnits(user, isChecked);

            prefUnits.setText(isChecked ? "kg" : "lbs");

            updateDisplayedWeights(currentWeightText, goalWeightText, weeklyGoalText, currentWeight, goals, isChecked);



        }));

        usernameText.setText(user);



        if(!goals.isEmpty()) {
            String goalWeight = goals.get("goalWeight");
            String weeklyGoal = goals.get("goalLoss");
            String projectedDate = goals.get("projectedDate");

            String unit = useKg ? "kg" : "lbs";

            if(currentWeight != null) {
                double current = Double.parseDouble(currentWeight);
                double displayCurrent = WeightDatabase.toDisplayWeight(current, useKg);
                currentWeightText.setText(String.format(Locale.getDefault(), "%.1f %s", displayCurrent, unit));
            }

            if(goalWeight != null) {
                double goal = Double.parseDouble(goalWeight);
                double displayGoal = WeightDatabase.toDisplayWeight(goal, useKg);
                goalWeightText.setText(String.format(Locale.getDefault(), "%.1f %s", displayGoal, unit));
            }

            if(weeklyGoal != null) {
                double weekGoal = Double.parseDouble(weeklyGoal);
                double displayWeek = WeightDatabase.toDisplayWeight(weekGoal, useKg);
                weeklyGoalText.setText(String.format(Locale.getDefault(), "%.1f %s/week", displayWeek, unit));
            }

            if(projectedDate != null) {
                goalDateText.setText(projectedDate);
            }

            prefUnits.setText(unit);
        }

    }

    private void updateDisplayedWeights(TextView currentWeightText, TextView goalWeightText, TextView weeklyGoalText, String currentWeight, Map<String, String> goals, boolean useKg) {
        String unit = useKg ? "kg" : "lbs";
        String goalWeight = goals.get("goalWeight");
        String weeklyGoal = goals.get("goalLoss");

        if(currentWeight != null) {
            double current = Double.parseDouble(currentWeight);
            double displayCurr = WeightDatabase.toDisplayWeight(current, useKg);

            currentWeightText.setText(String.format(Locale.getDefault(), "%.1f %s", displayCurr, unit));
        }

        if(goalWeight != null) {
            double goal = Double.parseDouble(goalWeight);
            double displayGoal = WeightDatabase.toDisplayWeight(goal, useKg);

            goalWeightText.setText(String.format(Locale.getDefault(), "%.1f %s", displayGoal, unit));
        }

        if(weeklyGoal != null) {
            double weekly = Double.parseDouble(weeklyGoal);
            double displayWeekly = WeightDatabase.toDisplayWeight(weekly, useKg);

            weeklyGoalText.setText(String.format(Locale.getDefault(), "%.1f %s/week", displayWeekly, unit));
        }
    }

}

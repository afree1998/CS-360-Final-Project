package com.example.projecttwo_austinfreeman;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;

import java.util.ArrayList;
import java.util.Locale;

public class GridViewCreator extends ArrayAdapter<Model> {
    private boolean useKg;
    public GridViewCreator(Context context, ArrayList<Model> list, boolean useKg) {
        super(context, 0, list);
        this.useKg = useKg;
    }

    //This is the grid builder. We create a calendar that we can use.
    //GeeksforGeeks was great in helping create this
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View itemView = convertView;

        if(itemView == null) {
            itemView = LayoutInflater.from(getContext()).inflate(R.layout.item_card, parent, false);
        }

        Model model = getItem(position);

        TextView text = itemView.findViewById(R.id.text_view);
        TextView weight = itemView.findViewById(R.id.weight);
        CardView c = itemView.findViewById(R.id.card);

        try {
            assert model != null;



            if (model.getClickable()) {
                text.setText(model.getDate());
                if(model.getWeight()  >= 0) {
                    double value = model.getWeight();
                    double displayWeight = WeightDatabase.toDisplayWeight(value, useKg);

                    String unit = useKg ? "kg" : "lbs";

                    weight.setText(String.format(Locale.getDefault(), "%.1f %s", displayWeight, unit));
                } else {
                    weight.setText("");
                }

                if(model.getTrend() == -1) {
                    c.setCardBackgroundColor(Color.parseColor("#DDF4DF"));
                } else if (model.getTrend() == 1) {
                    c.setCardBackgroundColor(Color.parseColor("#F8DDDD"));
                } else if(model.getTrend() == 2) {
                    c.setCardBackgroundColor(Color.parseColor("#FFD700"));
                }else {
                    c.setCardBackgroundColor(Color.parseColor("#FFFFFF"));
                }
            } else {
                text.setText(model.getDate());
                weight.setText("");
                c.setBackgroundColor(Color.parseColor("#FFFFFF"));
                c.setOnClickListener(null);
            }
        } catch (Exception e) {
            System.out.println("Error: " + e);
        }



        return itemView;
    }
}

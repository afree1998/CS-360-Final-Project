package com.example.projecttwo_austinfreeman;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class WeightDatabase extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "info.db";
    private static final int VERSION = 3;
    public WeightDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL("CREATE TABLE " + WeightTable.TABLE + " (" +
                WeightTable.COL_USER + " TEXT, " +
                WeightTable.COL_AGE + " TEXT, " +
                WeightTable.COL_DATE + " TEXT, " +
                WeightTable.COL_WEIGHT + " TEXT, " +
                WeightTable.COL_ENTRY + " INTEGER, " +
                "PRIMARY KEY(" +
                WeightTable.COL_USER + ", " +
                WeightTable.COL_DATE + ", " +
                WeightTable.COL_ENTRY + "))"
        );

        db.execSQL("CREATE TABLE " + GoalTable.TABLE + " (" +
                GoalTable.COL_USER + " TEXT PRIMARY KEY, " +
                GoalTable.COL_GOAL_WEIGHT + " TEXT, " +
                GoalTable.COL_GOAL_LOSS + " TEXT, " +
                GoalTable.COL_PROJECTED_DATE + " TEXT, " +
                GoalTable.COL_TOGGLE + " INTEGER)"
        );
    }
    private static final class GoalTable {
        private static final String TABLE = "goals";
        private static final String COL_USER = "username";
        private static final String COL_GOAL_WEIGHT = "goal_weight";
        private static final String COL_GOAL_LOSS = "goal_loss";
        private static final String COL_PROJECTED_DATE = "projected_date";
        private static final String COL_TOGGLE = "toggle";
    }
    private static final class WeightTable{
        private static final String TABLE = "info";
        private static final String COL_USER = "username";
        private static final String COL_AGE = "age";
        private static final String COL_DATE = "date";
        private static final String COL_ENTRY = "count";
        private static final String COL_WEIGHT = "weight";

    }



    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + WeightDatabase.WeightTable.TABLE);
        onCreate(db);
    }

    public int getEntryMaxNum(String date, String user) {
        SQLiteDatabase db = getReadableDatabase();

        String sql = "Select * from " + WeightTable.TABLE + " where " + WeightTable.COL_DATE + "= ? and " + WeightTable.COL_USER + "= ? order by " + WeightTable.COL_ENTRY + " desc limit 1;";
        Cursor c = db.rawQuery(sql, new String[]{date, user});

        int entry = 0;

        if(c.moveToFirst()) {
            entry = c.getInt(c.getColumnIndexOrThrow(WeightTable.COL_ENTRY));
        }
        c.close();

        return entry;
    }

    public Map<String, String> getUserEntries(String user, String month) {
        Map<String, String> results = new HashMap<>();

        SQLiteDatabase db = getReadableDatabase();
        String sql = "Select * from " +
                WeightTable.TABLE + " where " +
                WeightTable.COL_USER + "= ? and " +
                WeightTable.COL_DATE + " like ?" + " order by " +
                WeightTable.COL_DATE;

        Cursor c = db.rawQuery(sql, new String[]{user, month + "%"});

        try {
            while(c.moveToNext()) {
                String date = c.getString(c.getColumnIndexOrThrow(WeightTable.COL_DATE));
                String weight = c.getString(c.getColumnIndexOrThrow(WeightTable.COL_WEIGHT));
                results.put(date, weight);
                Log.d("DB", "Date: " + date + ", Weight: " + weight);
            }
        } finally {
            c.close();
        }
        return results;
    }

    public long createEntry(String user, String date, String weight, boolean useKg) {

        SQLiteDatabase db = getWritableDatabase();

        double enteredWeight = Double.parseDouble(weight);
        double storedWeight = toStoredWeight(enteredWeight, useKg);

        ContentValues values = new ContentValues();

        values.put(WeightTable.COL_USER, user);
        values.put(WeightTable.COL_DATE, date);
        values.put(WeightTable.COL_WEIGHT, Double.toString(storedWeight));

        int entry = getEntryMaxNum(date, user) + 1;

        values.put(WeightTable.COL_ENTRY, entry);

        return db.insert(WeightTable.TABLE, null, values);
    }
    public int updateWeight(String user, String date, int entry, String newWeight, boolean useKg) {

        SQLiteDatabase db = getWritableDatabase();

        double enteredWeight = Double.parseDouble(newWeight);
        double storedWeight = toStoredWeight(enteredWeight, useKg);

        ContentValues values = new ContentValues();
        values.put(WeightTable.COL_WEIGHT, Double.toString(storedWeight));

        return db.update(WeightTable.TABLE, values,
                WeightTable.COL_USER + " = ? AND " +
                        WeightTable.COL_DATE + " = ? AND " +
                        WeightTable.COL_ENTRY + " = ?",
                new String[]{user, date, String.valueOf(entry)});
    }

    public long saveGoals(String user, String goalWeight, String goalLoss, String projectedDate, boolean toggle) {

        SQLiteDatabase db = getWritableDatabase();


        double storedWeightGoal = toStoredWeight(Double.parseDouble(goalWeight), toggle);
        double storedGoalLoss = toStoredWeight(Double.parseDouble(goalLoss), toggle);

        ContentValues values = new ContentValues();

        values.put(GoalTable.COL_USER, user);
        values.put(GoalTable.COL_GOAL_WEIGHT, Double.toString(storedWeightGoal));
        values.put(GoalTable.COL_GOAL_LOSS, Double.toString(storedGoalLoss));
        values.put(GoalTable.COL_PROJECTED_DATE, projectedDate);
        values.put(GoalTable.COL_TOGGLE, toggle ? 1 : 0);

        return db.insertWithOnConflict(GoalTable.TABLE, null, values, SQLiteDatabase.CONFLICT_REPLACE);
    }

    public String getLatestWeight(String user) {
        SQLiteDatabase db = getReadableDatabase();

        String sql = "select " + WeightTable.COL_WEIGHT +
                " from " + WeightTable.TABLE +
                " where " + WeightTable.COL_USER + " = ? " +
                " order by " + WeightTable.COL_DATE + " desc, " +
                WeightTable.COL_ENTRY + " desc" +
                " limit 1";

        Cursor c = db.rawQuery(sql, new String[]{user});

        String weight = null;

        if(c.moveToFirst()) {
            weight = c.getString(c.getColumnIndexOrThrow(WeightTable.COL_WEIGHT));
        }
        c.close();

        return weight;
    }

    public Map<String, String> getGoals(String user) {

        Map<String, String> goals = new HashMap<>();

        SQLiteDatabase db = getReadableDatabase();

        String sql = "SELECT * FROM " + GoalTable.TABLE + " WHERE " + GoalTable.COL_USER + " = ?";

        Cursor c = db.rawQuery(sql, new String[]{user});

        if (c.moveToFirst()) {
            goals.put("goalWeight", c.getString(c.getColumnIndexOrThrow(GoalTable.COL_GOAL_WEIGHT)));
            goals.put("goalLoss", c.getString(c.getColumnIndexOrThrow(GoalTable.COL_GOAL_LOSS)));
            goals.put("projectedDate", c.getString(c.getColumnIndexOrThrow(GoalTable.COL_PROJECTED_DATE)));
            goals.put("toggle", String.valueOf(c.getInt(c.getColumnIndexOrThrow(GoalTable.COL_TOGGLE))));
        }

        c.close();

        return goals;
    }

    public void setPrefUnits(String user, boolean useKg) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(GoalTable.COL_TOGGLE, useKg ? 1 : 0);

        int rows = db.update(GoalTable.TABLE, values, GoalTable.COL_USER + " = ?", new String[]{user});

        if(rows == 0) {
            values.put(GoalTable.COL_USER, user);
            db.insert(GoalTable.TABLE, null, values);
        }
    }

    public String getWeightForDate(String user, String date) {
        SQLiteDatabase db = getReadableDatabase();

        String sql = "select " + WeightTable.COL_WEIGHT +
                " from " + WeightTable.TABLE +
                " where " + WeightTable.COL_USER + " = ? " +
                " and " + WeightTable.COL_DATE + " = ? " +
                " order by " + WeightTable.COL_ENTRY + " desc " +
                " limit 1";

        Cursor c = db.rawQuery(sql, new String[]{user, date});

        String weight = null;

        if(c.moveToFirst()) {
            weight = c.getString(c.getColumnIndexOrThrow(WeightTable.COL_WEIGHT));
        }
        c.close();
        return weight;
    }
    public static double toStoredWeight(double value, boolean useKg) {
        if(useKg) {
            return value / 0.4539237;
        }
        return value;
    }

    public static double toDisplayWeight(double value, boolean useKg) {
        if(useKg) {
            return value * 0.45359237;
        }
        return value;
    }
}
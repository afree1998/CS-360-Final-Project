package com.example.projecttwo_austinfreeman;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegisterActivity extends AppCompatActivity {

    UserDatabase dbHelper;

    @Override
    protected void onCreate(Bundle instance) {
        super.onCreate(instance);
        setContentView(R.layout.register_screen);

        dbHelper = new UserDatabase(this);


        Button b = findViewById(R.id.button);
        EditText user = findViewById(R.id.username);

        EditText pass = findViewById(R.id.password);
        EditText passVer = findViewById(R.id.password2);

        b.setOnClickListener(v -> {
            String username = user.getText().toString();
            String password = pass.getText().toString();
            String verifyPassword = passVer.getText().toString();

            if(!password.equals(verifyPassword)) {
                Toast.makeText(RegisterActivity.this, "Passwords don't match...", Toast.LENGTH_SHORT).show();
                return;
            }

            long newUserId = dbHelper.createUser(username, password);

            if(newUserId != -1) {
                dbHelper.logIn(newUserId);
                Toast.makeText(RegisterActivity.this, "Entry valid...", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(
                        RegisterActivity.this, DiaryActivity.class
                );
                startActivity(i);
                finish();
            } else {
                Toast.makeText(RegisterActivity.this, "Unable to create account...", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private boolean usernameCheck(String s) {
        Pattern expectedRes = Pattern.compile("^[a-zA-Z][a-zA-Z0-9_-]{3,16}$");

        Matcher m = expectedRes.matcher(s);

        return m.matches();
    }
    private boolean passwordCheck(String p) {
        Pattern expectedPass = Pattern.compile("^(?=.*[a-z])(?=.*[A-Z])(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$");

        Matcher m = expectedPass.matcher(p);

        return m.matches();
    }

    private long existsAndOpen(String user, String pass) {
        boolean entryValid = (usernameCheck(user) && passwordCheck(pass));

        if(dbHelper.userExists(user) != -1) {
            return -1;
        }
        if(entryValid) {
            return dbHelper.createUser(user, pass);
        }
        return -1;

    }
}
